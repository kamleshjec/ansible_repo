Role Name
=========

Manages the time server configurations for RHEL severs within VF Hosting

Requirements
------------

None

Role Variables
--------------

The information for NTP should be defined within the site YAML file.

ntp list of site based time servers to be used for sysnchronisation
ntp_server:
  - ip:   - IP of NTP server
    name: -  Optional name for time server
site_desc: Siet description used in templates
```

Example:
site_desc: "Vodafone Test Site"
ntp_server:
  - ip: 217.135.9.9
    name:
  - ip: 217.135.9.10
    name:
  - ip: 217.135.9.102
    name:
  - ip: 217.135.9.103
    name:
  - ip: 217.135.9.168
    name:
  - ip: 217.135.9.169
    name:
```

Dependencies
------------

None

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: ansible-role-ntp-rhel }

License
-------

IBM

Author Information
------------------

Andy McDougall [andrew.mcdougall@ibm.com]
